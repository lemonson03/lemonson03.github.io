import React, { useEffect, useRef, useState } from "react";
import './style.scss'
import './win.scss'
import './playerArea.scss'

const margin = 30;
const ROW = 18 // 바둑판 선 개수
const STONE_RADIUS = 19; // 바둑돌 크기
const COLORS = ['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink'];
const CELL_SIZE = 800 + margin * 2; // 바둑판 한 칸 크기
const INITIAL_TIME = 180; // 3 minutes in seconds

const PlayGround: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [board, setBoard] = useState<{ ply: number; color: string }[][]>(Array.from({ length: ROW }, () => Array(ROW).fill({ ply: 0, color: '' })));
  const [isBlackTurn, setIsBlackTurn] = useState(true);
  const [moves, setMoves] = useState<{ x: number; y: number }[]>([]);
  const [selectedColors, setSelectedColors] = useState<{ P1: string; P2: string }>({ P1: 'red', P2: 'red' });
  const [winner, setWinner] = useState<number | null>(null);
  const [pendingMove, setPendingMove] = useState<{ x: number; y: number } | null>(null);
  const [timers, setTimers] = useState<{ P1: number; P2: number }>({ P1: INITIAL_TIME, P2: INITIAL_TIME });
  const [gameStarted, setGameStarted] = useState(false);


  useEffect(() => {
    if (!gameStarted || winner !== null) return;

    const interval = setInterval(() => {
      setTimers(prev => {
        const currentPlayer = isBlackTurn ? 'P1' : 'P2';
        const newTime = Math.max(prev[currentPlayer] - 1, 0);
        return { ...prev, [currentPlayer]: newTime };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isBlackTurn, winner, gameStarted]);


  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      if (ctx) {
        drawBoard(ctx);
        drawStones(ctx);
        if (pendingMove) {
          drawRect(ctx, pendingMove.x, pendingMove.y);
        }
      }
    }
  }, [board, pendingMove, winner]);

  const drawBoard = (ctx: CanvasRenderingContext2D) => {
    ctx.clearRect(0, 0, CELL_SIZE, CELL_SIZE);
    ctx.fillStyle = "#d3e3fd";
    ctx.fillRect(0, 0, CELL_SIZE, CELL_SIZE);
    ctx.strokeStyle = "#041e49";

    const rowSize = 800 / ROW;
    const dolSize = 10;

    for (let x = 0; x < ROW; x++) {
      for (let y = 0; y < ROW; y++) {
        ctx.strokeRect(rowSize * x + margin, rowSize * y + margin, rowSize, rowSize);
      }
    }

    for (let a = 0; a < 3; a++) {
      for (let b = 0; b < 3; b++) {
        ctx.fillStyle = '#041e49';
        ctx.beginPath();
        ctx.arc(
          (3 + a * 6) * rowSize + margin,
          (3 + b * 6) * rowSize + margin,
          dolSize / 3,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
    }
  };

  const drawStones = (ctx: CanvasRenderingContext2D) => {
    const cellSize = 800 / ROW;
    board.forEach((row, y) => {
      row.forEach((cell, x) => {
        if (cell.ply !== 0) {
          ctx.beginPath();
          ctx.arc(
            x * cellSize + margin,
            y * cellSize + margin,
            STONE_RADIUS,
            0,
            Math.PI * 2
          );
          const stoneColor =
            winner !== null
              ? (cell.ply === 1 ? 'black' : 'white')
              : cell.color;
          ctx.fillStyle = stoneColor;
          ctx.fill();
        }
      });
    });
  };

  const drawRect = (ctx: CanvasRenderingContext2D, x: number, y: number) => {
    const w = 800 / ROW;
    ctx.strokeStyle = 'red';
    ctx.lineWidth = 1;
    ctx.strokeRect(
      x * w + margin - w / 2,
      y * w + margin - w / 2,
      w,
      w
    );
  };

  const handleClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (winner !== null) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((event.clientX - rect.left - margin + (800 / ROW) / 2) / (800 / ROW));
    const y = Math.floor((event.clientY - rect.top - margin + (800 / ROW) / 2) / (800 / ROW));

    if (x >= 0 && x < ROW && y >= 0 && y < ROW && board[y][x].ply === 0) {
      setPendingMove({ x, y });
    }
  };

  const changeColorAndSize = ({ color, num }: { color: string; num: number }) => {
    setSelectedColors(prevColors => ({
      ...prevColors,
      [num === 1 ? 'P2' : 'P1']: color
    }));
  }

  const undoMove = () => {
    if (moves.length > 0) {
      const lastMove = moves[moves.length - 1];
      const newBoard = board.map(row => [...row]);
      newBoard[lastMove.y][lastMove.x] = { ply: 0, color: '' };
      setBoard(newBoard);
      setMoves(moves.slice(0, -1));
      setIsBlackTurn(!isBlackTurn);
    }
  };

  const placeStone = () => {
    if (!pendingMove) return;

    if (!gameStarted) {
      setGameStarted(true);
    }

    const { x, y } = pendingMove;

    if (board[y][x].ply !== 0) {
      setPendingMove(null);
      return;
    }

    const newBoard = board.map(row => row.map(cell => ({ ...cell })));
    const currentPlayer = isBlackTurn ? 1 : 2;
    newBoard[y][x] = { ply: currentPlayer, color: selectedColors[currentPlayer === 1 ? 'P1' : 'P2'] };
    setBoard(newBoard);
    setMoves(prev => [...prev, { x, y }]);

    if (checkWin(newBoard, x, y, currentPlayer)) {
      setWinner(currentPlayer);
    } else {
      setIsBlackTurn(prev => !prev);
    }

    setPendingMove(null);
  };

  const checkWin = (board: { ply: number; color: string }[][], x: number, y: number, player: number): boolean => {
    const directions = [
      { dx: 1, dy: 0 },
      { dx: 0, dy: 1 },
      { dx: 1, dy: 1 },
      { dx: 1, dy: -1 }
    ];

    return directions.some(({ dx, dy }) => {
      let count = 1;

      for (let i = 1; i < 5; i++) {
        const nx = x + dx * i;
        const ny = y + dy * i;
        if (nx >= 0 && nx < ROW && ny >= 0 && ny < ROW && board[ny][nx].ply === player) {
          count++;
        } else {
          break;
        }
      }

      for (let i = 1; i < 5; i++) {
        const nx = x - dx * i;
        const ny = y - dy * i;
        if (nx >= 0 && nx < ROW && ny >= 0 && ny < ROW && board[ny][nx].ply === player) {
          count++;
        } else {
          break;
        }
      }

      return count >= 5;
    });
  };

  useEffect(() => {
    if (moves.length > 0) {
      const lastMove = moves[moves.length - 1];
      const player = isBlackTurn ? 2 : 1;
      if (checkWin(board, lastMove.x, lastMove.y, player)) {
        setWinner(player);
      }
    }
  }, [moves]);

  const formatTime = (seconds: number): string => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="BLindFiveMock">
      <section className={"Main"}>
        <div className={"GameName"} >{'Blind Five mok'}</div>
        <div className="Control">
          <div>
            <button onClick={undoMove} className={"Withdraw"}>{'무르기'}</button>
          </div>
          <div>
            <button className="Reload">{'다시하기'}</button>
          </div>
        </div>
        <section />

        <section className="PlayArea">
          {winner &&
            <div className={`WinShow ${winner === 1 ? 'Black' : 'White'}`}>{`Player${winner} 승리!`}
              <div className="Trophy">
                <img className={"TrophyImg"} src={"./trophy.png"} width={'200px'} height={'200px'} alt={""} />
              </div>
            </div>
          }

          <div className="CanvasContainer">
            <canvas ref={canvasRef} onClick={handleClick} width={CELL_SIZE} height={CELL_SIZE} />
          </div>

          {(['P1', 'P2'] as const).map((player, index) => {
            const isCurrentTurn = isBlackTurn ? index === 0 : index === 1;
            return (
              <div key={player} className={`PlayerArea ${player}`}>
                <div className={'Btns'}>
                  {COLORS.map(color =>
                    <button
                      key={color}
                      className={`ColorBtn ${color} ${selectedColors[player] === color ? 'Selected' : ''}`}
                      onClick={() => isCurrentTurn && changeColorAndSize({ color, num: index })}
                      style={{ visibility: isCurrentTurn ? 'visible' : 'hidden' }}
                    >
                    </button>
                  )}
                  <button
                    className={'PlaceStoneBtn'}
                    onClick={() => isCurrentTurn && placeStone()}
                    style={{ visibility: isCurrentTurn ? 'visible' : 'hidden' }}
                  >
                    {'착수'}
                  </button>
                </div>
                <div className={'Timer'}>{formatTime(timers[player])}</div>
              </div>
            )
          })}
          <section />
        </section>
      </section>
    </div>
  )
}

export default PlayGround;
